﻿namespace Chat
{
    class Program
    {
        static void Main(string[] args)
        {
            Substrings substrings = new Substrings();

            Learning learning = new Learning();

            substrings.Sub();
            learning.Learn();

        }
    }
}
